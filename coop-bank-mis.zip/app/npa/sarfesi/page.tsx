import { Suspense } from "react"
import { SARFESIData } from "@/components/sarfesi-data"
import { SARFESIActions } from "@/components/sarfesi-actions"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ErrorBoundary } from "react-error-boundary"

async function fetchSARFESIData() {
  // In a real-world scenario, this would be an API call to your backend
  const res = await fetch("https://api.example.com/sarfesi-data", { next: { revalidate: 3600 } })
  if (!res.ok) throw new Error("Failed to fetch SARFESI data")
  return res.json()
}

export default async function SARFESIPage() {
  const sarfesiData = await fetchSARFESIData()

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">SARFESI Advanced Features</h1>
      <div className="grid gap-4 md:grid-cols-2">
        <ErrorBoundary fallback={<div>Error loading SARFESI data</div>}>
          <Suspense
            fallback={
              <Card>
                <CardContent>Loading SARFESI data...</CardContent>
              </Card>
            }
          >
            <SARFESIData data={sarfesiData} />
          </Suspense>
        </ErrorBoundary>
        <Card>
          <CardHeader>
            <CardTitle>SARFESI Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <SARFESIActions />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

